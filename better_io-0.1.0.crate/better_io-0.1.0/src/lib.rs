pub use buf_read::BetterBufRead;
pub use buf_reader::BetterBufReader;

mod buf_read;
mod buf_reader;
